package com.ctel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserRegistrationAndLoginProcessWithJwtApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserRegistrationAndLoginProcessWithJwtApplication.class, args);
	}

}
