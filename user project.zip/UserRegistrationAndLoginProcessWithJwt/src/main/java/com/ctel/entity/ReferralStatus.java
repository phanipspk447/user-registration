package com.ctel.entity;

public enum ReferralStatus {
    PENDING,
    SUCCESSFUL
}