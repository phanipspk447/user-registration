package com.ctel.entity;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

@Entity
@Table(name = "users_registration_table")
public class User {
	  @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

//	    @Column(unique = true, nullable = false)
	    private String username;

	    @Column(unique = true, nullable = false)
//	    @Column(name = "email", unique = true, columnDefinition = "VARCHAR(255) BINARY")
	    private String email;

	    @Column(nullable = false)
	    private String passwordHash;

	    @Column(unique = true)
	    private String referralCode;

	    @ManyToOne
	    @JsonManagedReference // Allows proper serialization of referred users
//	    @JsonBackReference // Prevents infinite recursion in JSON serialization
	    @JoinColumn(name = "referred_by")
	    private User referredBy;

	    @OneToMany(mappedBy = "referredBy", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
//	    @JsonManagedReference // Allows proper serialization of referred users
	    @JsonBackReference // Prevents infinite recursion in JSON serialization
	    private List<User> referrals = new ArrayList<>();

	    private LocalDateTime createdAt = LocalDateTime.now();
		@Transient
		@JsonIgnore  // This will exclude resetTokenExpiry from JSON response. [Don't show this "resetTokenExpiry" field the response payload]
	    private String resetToken;
		@Transient
		@JsonIgnore  // This will exclude resetTokenExpiry from JSON response.[Don't show this "resetTokenExpiry" field the response payload]
	    private LocalDateTime resetTokenExpiry;
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public String getUsername() {
			return username;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getPasswordHash() {
			return passwordHash;
		}
		public void setPasswordHash(String passwordHash) {
			this.passwordHash = passwordHash;
		}
		public String getReferralCode() {
			return referralCode;
		}
		public void setReferralCode(String referralCode) {
			this.referralCode = referralCode;
		}
		public User getReferredBy() {
			return referredBy;
		}
		public void setReferredBy(User referredBy) {
			this.referredBy = referredBy;
		}
		public List<User> getReferrals() {
			return referrals;
		}
		public void setReferrals(List<User> referrals) {
			this.referrals = referrals;
		}
		public LocalDateTime getCreatedAt() {
			return createdAt;
		}
		public void setCreatedAt(LocalDateTime createdAt) {
			this.createdAt = createdAt;
		}
		public String getResetToken() {
			return resetToken;
		}
		public void setResetToken(String resetToken) {
			this.resetToken = resetToken;
		}
		public LocalDateTime getResetTokenExpiry() {
			return resetTokenExpiry;
		}
		public void setResetTokenExpiry(LocalDateTime resetTokenExpiry) {
			this.resetTokenExpiry = resetTokenExpiry;
		}
		public User(Long id, String username, String email, String passwordHash, String referralCode, User referredBy,
				List<User> referrals, LocalDateTime createdAt, String resetToken, LocalDateTime resetTokenExpiry) {
			super();
			this.id = id;
			this.username = username;
			this.email = email;
			this.passwordHash = passwordHash;
			this.referralCode = referralCode;
			this.referredBy = referredBy;
			this.referrals = referrals;
			this.createdAt = createdAt;
			this.resetToken = resetToken;
			this.resetTokenExpiry = resetTokenExpiry;
		}
		public User() {
			super();
		}
    
}
