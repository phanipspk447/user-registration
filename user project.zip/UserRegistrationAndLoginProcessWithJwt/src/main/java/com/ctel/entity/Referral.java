package com.ctel.entity;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "referrals")


public class Referral {
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	    @ManyToOne
	    @JsonBackReference // Prevents circular reference
	    @JoinColumn(name = "referrer_id", nullable = false)
	    private User referrer;

	    @ManyToOne
	    @JoinColumn(name = "referred_user_id")
	    private User referredUser;

	    @Column(nullable = false)
	    private LocalDateTime dateReferred = LocalDateTime.now();

	    @Enumerated(EnumType.STRING)
	    private ReferralStatus status;

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public User getReferrer() {
			return referrer;
		}

		public void setReferrer(User referrer) {
			this.referrer = referrer;
		}

		public User getReferredUser() {
			return referredUser;
		}

		public void setReferredUser(User referredUser) {
			this.referredUser = referredUser;
		}

		public LocalDateTime getDateReferred() {
			return dateReferred;
		}

		public void setDateReferred(LocalDateTime dateReferred) {
			this.dateReferred = dateReferred;
		}

		public ReferralStatus getStatus() {
			return status;
		}

		public void setStatus(ReferralStatus status) {
			this.status = status;
		}

		public Referral(Long id, User referrer, User referredUser, LocalDateTime dateReferred, ReferralStatus status) {
			super();
			this.id = id;
			this.referrer = referrer;
			this.referredUser = referredUser;
			this.dateReferred = dateReferred;
			this.status = status;
		}

		public Referral() {
			super();
		}
    
}

//enum ReferralStatus {
//    PENDING, SUCCESSFUL
//}
