package com.ctel.config;

import java.io.IOException;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.ctel.security.JwtAuthenticationFilter;
import com.ctel.service.UserService;
import com.ctel.util.JwtUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Configuration
public class SecurityConfig {

//	  @Autowired
//	    private JwtAuthenticationFilter jwtAuthFilter;
//	  
//	  @Bean
//	    public UserDetailsService userDetailsService() {
//	        return new UserService();
//	    }
	
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authenticationConfiguration) 
            throws Exception {
        return authenticationConfiguration.getAuthenticationManager();
    }

    //  Define JwtAuthenticationFilter as a Bean and pass AuthenticationManager
    @Bean
    public JwtAuthenticationFilter jwtAuthenticationFilter(JwtUtil jwtUtil, UserService userDetailsService, AuthenticationManager authenticationManager) {
        return new JwtAuthenticationFilter(jwtUtil, userDetailsService, authenticationManager);
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http, JwtAuthenticationFilter jwtAuthFilter) throws Exception {
        http
            .csrf(csrf -> csrf.disable()) // Disable CSRF for APIs
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/api/register", "/api/login", "/api/forgot-password").permitAll() // Public access
                .requestMatchers("/api/referral-status, /api/referrals").authenticated() // Requires authentication
                .anyRequest().authenticated()) // Require authentication for other APIs
            .exceptionHandling(exceptionHandling -> exceptionHandling
                  .authenticationEntryPoint(authenticationEntryPoint())  // Handle missing token
                  .accessDeniedHandler(accessDeniedHandler())  // Handle forbidden access
              )
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class); // Use injected bean

        return http.build();
    }
    
//THE BELOW METHOD IS USED TO HANDLE THE EXCEPTIONS    
    @Bean
    public AuthenticationEntryPoint authenticationEntryPoint() {
        return (request, response, authException) -> {
            response.setStatus(HttpStatus.UNAUTHORIZED.value());
            response.setContentType("application/json");
            response.getWriter().write("{\"status\":401, \"error\":\"Unauthorized\", \"message\":\"Token is missing or invalid\"}");
        };
    }

//THE BELOW METHOD IS USED TO HANDLE THE EXCEPTIONS
  @Bean
  public AccessDeniedHandler accessDeniedHandler() {
      return (request, response, accessDeniedException) -> {
          response.setStatus(HttpStatus.FORBIDDEN.value());
          response.setContentType("application/json");
          response.getWriter().write("{\"status\":403, \"error\":\"Forbidden\", \"message\":\"You do not have permission to access this resource\"}");
      };
  }
}