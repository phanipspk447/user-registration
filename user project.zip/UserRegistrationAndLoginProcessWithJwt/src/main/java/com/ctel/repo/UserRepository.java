package com.ctel.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ctel.entity.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    @Query(value = "SELECT * FROM users_registration_table WHERE BINARY email = :email", nativeQuery = true)
    Optional<User> findByEmail(String email);
    
//    @Query(value = "SELECT * FROM users_registration_table WHERE BINARY email = :email", nativeQuery = true)
//    Optional<User> findByEmailCaseSensitive(@Param("email") String email);
 
    Optional<User> findByUsername(String username);
    @Query("SELECT u FROM User u WHERE u.referralCode = :referralCode")
    Optional<User> findByReferralCode(@Param("referralCode") String referralCode);
    
    
    
    boolean existsByEmail(String email);
    boolean existsByUsername(String username);
//    Optional<User> findByReferralCode(String referralCode);
    long countByReferredBy(User referredBy);
}
