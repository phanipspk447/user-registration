package com.ctel.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ctel.entity.Referral;
import com.ctel.entity.User;

@Repository
public interface ReferralRepository extends JpaRepository<Referral, Long> {
    List<Referral> findByReferrer(User referrer);
    
    @Query("SELECT COUNT(r) FROM Referral r WHERE r.referrer.id = :userId AND r.status = 'SUCCESSFUL'")
    Long countSuccessfulReferrals(@Param("userId") Long userId);
    
    
    boolean existsByReferrerAndReferredUser(User referrer, User referredUser);
}