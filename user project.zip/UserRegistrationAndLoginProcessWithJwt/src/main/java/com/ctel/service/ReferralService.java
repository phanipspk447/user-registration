package com.ctel.service;

import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

//import org.springframework.security.core.userdetails.UsernameNotFoundException;


import com.ctel.entity.User;
import com.ctel.repo.ReferralRepository;
import com.ctel.repo.UserRepository;

@Service
//@RequiredArgsConstructor
public class ReferralService {
    
    private ReferralRepository referralRepository;

    
    private  UserRepository userRepository;

    public Long getSuccessfulReferrals(Long userId) {
        return referralRepository.countSuccessfulReferrals(userId);
    }

    public Long getUserIdByUsername(String username) {
        return userRepository.findByUsername(username)
                .map(User::getId)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));
    }
}

