package com.ctel.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.ctel.entity.Referral;
import com.ctel.entity.ReferralStatus;
import com.ctel.entity.User;
import com.ctel.repo.ReferralRepository;
import com.ctel.repo.UserRepository;

@Service
public class UserService implements UserDetailsService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private ReferralRepository referralRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	public ResponseEntity<?> registerUser( String username,  String email,String password, String referralCode) {

//  Check for existing username and email
		if (userRepository.existsByEmail(email)) {
			return ResponseEntity.badRequest().body(Map.of("error", "Email already in use"));
		}
//		if (userRepository.existsByUsername(username)) {
//			return ResponseEntity.badRequest().body(Map.of("error", "Username already taken"));
//		}

//  Validate referral code if provided
		User referredByUser = null;
		if (referralCode != null && !referralCode.isEmpty()) {
			referredByUser = userRepository.findByReferralCode(referralCode).orElse(null);
			if (referredByUser == null) {
				return ResponseEntity.badRequest().body(Map.of("error", "Invalid referral code"));
			}
		}

//  Create new user
		User newUser = new User();
		newUser.setUsername(username);
		newUser.setEmail(email);
		newUser.setPasswordHash(passwordEncoder.encode(password));
		newUser.setReferralCode(UUID.randomUUID().toString().substring(0, 8));
		newUser.setReferredBy(referredByUser);

//  Save new user
		User savedUser = userRepository.save(newUser);

//  Check and save referral only if not already present
		if (referredByUser != null) {
			boolean referralExists = referralRepository.existsByReferrerAndReferredUser(referredByUser, savedUser);
			if (!referralExists) {
				Referral referral = new Referral();
				referral.setReferrer(referredByUser);
				referral.setReferredUser(savedUser);
				referral.setStatus(ReferralStatus.SUCCESSFUL);
				referral.setDateReferred(LocalDateTime.now());

				referralRepository.save(referral);
			}
		}

		return ResponseEntity.ok(Map.of("message", "User registered successfully", "user", savedUser));
	}


	
	
////	---------------WE GET THE DATA WITH UNIQUE USERNAME" DETAILS -----------------------------------------
//	public List<Referral> getUserReferrals(String username) {
//		User user = userRepository.findByUsername(username).orElseThrow(() -> new RuntimeException("User not found"));
//		return referralRepository.findByReferrer(user);
//	}
	
	public List<Referral> getUserReferrals(String email) {
		User user = userRepository.findByEmail(email).orElseThrow(() -> new RuntimeException("User not found"));
		return referralRepository.findByReferrer(user);
	}

// --------------------	USER WANT TO LOGGED IN WITH "USERNAME" ---------------------------------
//	@Override
//	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
//		User user = userRepository.findByUsername(username)
//				.orElseThrow(() -> new UsernameNotFoundException("User not found with username: " + username));
//
//		return org.springframework.security.core.userdetails.User.withUsername(user.getUsername())
//				.password(user.getPasswordHash()) // Must match encoded password
//				.authorities("USER") // Role
//				.build();
//	}
	
	
// -------------------- USER WANT TO LOGGED IN WITH "EMAIL" -----------------------------------
	@Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("User not found with email: " + email));
        return new org.springframework.security.core.userdetails.User(
                user.getEmail(), user.getPasswordHash(), new ArrayList<>());
    }	

}
