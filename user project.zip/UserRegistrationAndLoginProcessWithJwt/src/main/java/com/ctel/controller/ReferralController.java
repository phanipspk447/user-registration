package com.ctel.controller;

import java.util.Collections;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ctel.service.ReferralService;
import com.ctel.service.UserService;
import com.ctel.util.JwtUtil;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api")
//@RequiredArgsConstructor
@Slf4j // For logging
public class ReferralController {

    private  ReferralService referralService;
    private  JwtUtil jwtUtil;
    private  UserService userService;
    
    private  final Logger log = LoggerFactory.getLogger(ReferralController.class);

    @GetMapping("/referral-stats")
    public ResponseEntity<?> getReferralStats(@RequestHeader("Authorization") String token) {
        try {
            if (token == null || !token.startsWith("Bearer ")) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body("Missing or invalid Authorization token");
            }

            // Extract JWT token (remove "Bearer " prefix)
            String jwtToken = token.substring(7);
            
            // Validate and extract username
            if (!jwtUtil.validateToken(jwtToken)) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid or expired token");
            }
            
            String username = jwtUtil.extractUsername(jwtToken);
            log.info("Extracted username from token: {}", username);

            // Get user ID from username
            Long userId = referralService.getUserIdByUsername(username);
            log.info("Retrieved userId: {}", userId);

            // Get referral statistics
            Long count = referralService.getSuccessfulReferrals(userId);
            return ResponseEntity.ok(Collections.singletonMap("successfulReferrals", count));

        } catch (Exception e) {
            log.error("Error retrieving referral statistics: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                 .body("Error retrieving referral statistics");
        }
    }
}

