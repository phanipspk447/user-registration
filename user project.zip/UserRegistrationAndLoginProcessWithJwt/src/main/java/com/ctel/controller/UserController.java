package com.ctel.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ctel.entity.Referral;
import com.ctel.entity.User;
import com.ctel.repo.UserRepository;
import com.ctel.service.UserService;
import com.ctel.util.JwtUtil;

@RestController
@RequestMapping("/api")
public class UserController {

	@Autowired
	private UserService userService;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private JwtUtil jwtUtil;

	@PostMapping("/register")
	public ResponseEntity<?> registerUser(@RequestBody Map<String, String> request) {
		String username = request.get("username");
		String email = request.get("email");
		String password = request.get("password");
		String referralCode = request.get("referralCode"); // Optional

		return userService.registerUser(username, email, password, referralCode);
	}


	@PostMapping("/login")
	public ResponseEntity<?> login(@RequestBody Map<String, String> request) {
//		String username = request.get("username");
		 String email = request.get("email");
		String password = request.get("password");

		System.out.println("Attempting login for username: " + email);

		try {
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(email, password));
			System.out.println("Authentication successful for email: " + email);

			String token = jwtUtil.generateToken(email);

			return ResponseEntity.ok(Map.of("message", "User Logged in Successfully", "token", token));
		} catch (BadCredentialsException e) {
			System.out.println("Invalid credentials for email: " + email);
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "Invalid username or password"));
		} catch (UsernameNotFoundException e) {
	        System.out.println("User not found: " + email);
	        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "Invalid email or password"));
	    }catch (Exception e) {
			System.out.println("Error during login: " + e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(Map.of("error", "An error occurred while processing your request"));
		}
	}
	
	
	
	@GetMapping("/referrals")
	public ResponseEntity<List<Referral>> getReferrals(@RequestParam String email) {
		return ResponseEntity.ok(userService.getUserReferrals(email));
	}
	
	
	@GetMapping("/referral-status")
	public ResponseEntity<?> getReferralStats() {
	    try {
	        // Get the authenticated user's details
	        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

	        if (authentication == null || !authentication.isAuthenticated()) {
	            throw new RuntimeException("Unauthorized: Token is missing or invalid");
	        }

	        String email = authentication.getName(); //  Get email instead of username
	        
//          // Fetch user from database by "USERNAME"
//          User user = userRepository.findByUsername(username)
//                  .orElseThrow(() -> new RuntimeException("User not found"));
	        

	        // Fetch user from database by email
	        User user = userRepository.findByEmail(email)
	                .orElseThrow(() -> new RuntimeException("User not found"));

	        // Count successful referrals
	        long successfulReferrals = userRepository.countByReferredBy(user);

	        // Prepare response
	        Map<String, Object> response = new HashMap<>();
//	        response.put("email", user.getEmail()); //  Return email instead of username
	        response.put("username", user.getUsername()); //  Return username instead of email
	        response.put("referral_code", user.getReferralCode());
	        response.put("successful_referrals", successfulReferrals);

	        return ResponseEntity.ok(response);
	    } catch (RuntimeException ex) {
	        return handleUnauthorizedException(ex);
	    }
	}
	// Exception Handler for Unauthorized Access
	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<Map<String, Object>> handleUnauthorizedException(RuntimeException ex) {
	    Map<String, Object> errorResponse = new HashMap<>();
	    errorResponse.put("status", HttpStatus.UNAUTHORIZED.value());
	    errorResponse.put("error", "Unauthorized");
	    errorResponse.put("message", ex.getMessage());

	    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(errorResponse);
	}

	
	
}
